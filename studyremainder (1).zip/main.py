 #Project Title: Study Remainder Ai(Temporary )
 #Group Members: Aevery Kye F. Montenegro, Valther Gabriel D. Rosario, Dianne Pauline B. Solonia
 #Description:

fname, lname = get_name()

print("Hello", fname, lname)

sub, time = get_study_deta()
result = evalu_remainder(r)

print (result)
print("Study", subject, "for", remainder, "minutes")

def get_name():
    fname = input("Enter first name: ")
    lname = input("Enter last name: ")
    if fname == "" or lname == "":
        print("Invalid input: Name cannot be empty!")
        return get_name()
    return fname, lname
    
def get_study_deta():
        sub = input("Enter subject: ")
        remainder = int(input("Enter time (minutes): "))
        return sub, remainder
            
def evaluate_remainder(remainder):
    if remainder < 30:
        return "Short review!"
    elif remainder <= 60:
        return "Good study time!"
    else:
        return "Outstanding study session!"
        
        
        
        
    

